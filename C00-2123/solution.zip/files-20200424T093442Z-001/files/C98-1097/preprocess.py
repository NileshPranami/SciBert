import csv


with open(in_fnam) as in_file:
    with open(out_fnam, 'w') as out_file:
        writer = csv.writer(out_file)
        for row in csv.reader(in_file):
            if row:
                writer.writerow(row)
