
from bert_serving.client import BertClient
from sklearn.metrics.pairwise import cosine_similarity
import csv

client = BertClient(check_length=False)

filepath = 'finalSent1.txt'
outpath = 'result2.csv'
count = len(open(filepath).readlines())

with open(outpath, 'w', newline = '')as f:
	thewriter = csv.writer(f)
	listRow = [*range(0,count,1)]
	listRow.insert(0,' ')
	print(listRow)
	thewriter.writerow(listRow)
	with open(filepath)as fp:
		for cnt, line in enumerate(fp):
			lRow = list()
			lRow.append(cnt)
			with open(filepath) as fp1:
				for cnt1, line1 in enumerate(fp1):
					list1 = list()
					list2 = list()
				
					list1.append(line.lower())
					list2.append(line1.lower())
					v1 = client.encode(list1)
					v2 = client.encode(list2)
					distance = cosine_similarity(v1, v2)
					lRow.append(distance[0][0])

			print(lRow)
			thewriter.writerow(lRow)



