import pandas as pd
import csv

filename = 'file22.csv'
outpath = 'output3.csv'
df = pd.read_csv(filename)


with open(outpath,'w', newline = '') as f:
	thewriter = csv.writer(f)

	thewriter.writerow(['Reference','Reference Text'])
	for index, line in df.iterrows():
		
		sent = line['Reference Text'].lower().split('. ')
		for line1 in sent:
			print(line1)
			if len(line1) < 10:
				print('__________________________________________')
				continue
			sent = (line['Reference'], line1.strip())
			# sent.append()
			thewriter.writerow(sent)
			
		
f.close()