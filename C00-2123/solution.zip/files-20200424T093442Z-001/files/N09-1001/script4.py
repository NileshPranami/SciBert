
from bert_serving.client import BertClient
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
#import gensim

client = BertClient(check_length=False)

filepath1 = 'file11.csv'
filepath2 = 'output3.csv'


f5=open('finalSent.txt','w')

def maxn(list1, N): 
    final_list = [] 
  
    for i in range(0, N):  
        max1 = (0,0)
          
        for j in range(len(list1)):      
            if list1[j][0] > max1[0]: 
                max1 = list1[j]; 
                  
        list1.remove(max1); 
        final_list.append(max1) 
          
    return final_list 		


df1 = pd.read_csv(filepath1)
df2 = pd.read_csv(filepath2)

for cnt, line in df1.iterrows():
	# f5.write(str(cnt))
	list1 = list()
	list1.append(line['Reference Text'].lower())
	result = list()
	# df2 = pd.read_csv(filepath)
	for cnt1, line1 in df2.iterrows():
		#start  =  time()	
		
		list2 = list()

		list2.append(line1['Reference Text'].lower())	
		
		v1 = client.encode(list1)
		v2 = client.encode(list2)
		distance = cosine_similarity(v1, v2)

		tu = (distance[0][0],line1["Reference Text"])
		result.append(tu)
		print("-----------------------------------------") 		
		
	result = maxn(result,5)
	for line3 in result:
		f5.write('\t'+str(line3[1]))
		f5.write('\n')
f5.close()		


